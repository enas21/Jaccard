import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
class Index{
    String name;
    double value;
    Index(String name ,double value){
        this.name = name;
        this.value = value;
    }
}
public class Jaccard {

    private HashSet<String> readFile(String fileName) throws Exception {
        BufferedReader file = new BufferedReader(new FileReader(fileName));
        String line;
        HashSet<String> wordsSet = new HashSet<>();
        while ((line = file.readLine()) != null) {
            String[] words = line.split("\\W+"); // split by any special char like ! or space or @ //to get every word of the line
            for (String word : words) {
                word = word.toLowerCase();
                wordsSet.add(word);
            }
        }
        return wordsSet;
    }

    private HashSet<String> intersect(HashSet<String> query, HashSet<String> fileWords) {
            HashSet<String>queryClone = new HashSet<String>(query);
            HashSet<String>fileWordsClone = new HashSet<String>(fileWords);

        if (queryClone.size()<=fileWordsClone.size()){

                HashSet<String> newQuery = new HashSet<>(queryClone);
                newQuery.removeAll(fileWordsClone);
                queryClone.removeAll(newQuery);
                return queryClone;
            }else{

                HashSet<String> newQuery = new HashSet<>(fileWordsClone);
                newQuery.removeAll(queryClone);
                fileWordsClone.removeAll(newQuery);
                return fileWordsClone;
            }

    }

    private HashSet<String> union(HashSet<String>query,HashSet<String> fileWords){
        HashSet<String>queryClone = new HashSet<String>(query);
        HashSet<String>fileWordsClone = new HashSet<String>(fileWords);
        queryClone.addAll(fileWordsClone);
        return queryClone;
    }

    private HashSet<String>slice(String query){

        HashSet<String> wordsSet = new HashSet<>();
            String[] words = query.split("\\W+"); // split by any special char like ! or space or @ //to get every word of the line
            for (String word : words) {
                word = word.toLowerCase();
                wordsSet.add(word);
            }

        return wordsSet;
    }

    public ArrayList<Index> jaccardSimilarity(String query , String []fileNames) throws Exception {
        ArrayList<Index>values = new ArrayList<>();
        for (String fileName :fileNames){
            HashSet<String> querySet = slice(query);
            HashSet<String>  wordSet = readFile(fileName);

            double intersectValue = (double) intersect(querySet,wordSet).size();
            double unionValue = (double) union(querySet,wordSet).size();
            Index index = new Index(fileName,intersectValue/unionValue);
            values.add(index);

        }

        return values;
    }


    static void sort(ArrayList<Index> arr) {


        // One by one move boundary of unsorted subarray
        for (int i = 0; i < arr.size(); i++)
        {
            // Find the minimum element in unsorted array
            int min_idx = i;
            for (int j = i+1; j < arr.size(); j++)
                if (arr.get(j).value > arr.get(min_idx).value)
                    min_idx = j;

            // Swap the found minimum element with the first
            // element
            Index temp = arr.get(min_idx);
            arr.set(min_idx,arr.get(i)) ;
            arr.set(i,temp) ;
        }
    }
    public static void main(String[] args) {

        Jaccard jaccard = new Jaccard();
        try{
            File directoryPath = new File("F:\\Projects\\Information Retrieval\\files");
            File files[] = directoryPath.listFiles();
            String filesNames[] = new String[files.length];
            int i =0;
            for(File file : files) {
              filesNames[i] = directoryPath +"\\"+ file.getName();
              System.out.println("File name: "+filesNames[i]);
              i=i+1;
            }
            ArrayList<Index> values= jaccard.jaccardSimilarity("idea of March",filesNames);
            sort(values);
            for (Index index :
                    values) {
                System.out.println(index.value+"  "+index.name);
            }


        }catch (Exception error){

            System.out.println(error.getMessage());
        }

    }







}
